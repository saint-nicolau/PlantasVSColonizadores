using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Planta3 : MonoBehaviour
{
    [SerializeField] private GameObject FirstModel;
    [SerializeField] private GameObject SecondModel;
    [SerializeField] private GameObject ThirdModel;

    private GameObject CurrentModel;

    public void NextModel()
    {
        if (CurrentModel == null || CurrentModel == FirstModel)
        {
            if (CurrentModel != null)
                CurrentModel.SetActive(false);

            SecondModel.SetActive(true);
            FirstModel.SetActive(false);
            CurrentModel = SecondModel;
        }
        else if (CurrentModel == SecondModel)
        {
            SecondModel.SetActive(false);

            ThirdModel.SetActive(true);
            SecondModel.SetActive(false);
            CurrentModel = ThirdModel;
        }
    }
    public void PreviousModel()
    {
        if (CurrentModel == ThirdModel)
        {
            if (CurrentModel != null)
                CurrentModel.SetActive(false);

            SecondModel.SetActive(true);
            ThirdModel.SetActive(false);
            CurrentModel = SecondModel;
        }
        else if (CurrentModel == SecondModel)
        {
            SecondModel.SetActive(false);

            FirstModel.SetActive(true);
            SecondModel.SetActive(false);
            CurrentModel = FirstModel;
        }
        else if (CurrentModel == FirstModel)
        {
            FirstModel.SetActive(true);
            SecondModel.SetActive(false);
        }
    }
}
