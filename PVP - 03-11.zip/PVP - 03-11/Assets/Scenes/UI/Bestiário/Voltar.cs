using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Voltar : MonoBehaviour
{
    public void SairBestiario()
    {
        SceneManager.LoadScene("MENU-UI");
        //Time.timeScale = 1;
    }
}
