using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class Bestiário : MonoBehaviour
{
    public void EntrarBestiario()
    {
        SceneManager.LoadScene("BESTIÁRIO");
        //Time.timeScale = 1;
    }
}