using Newtonsoft.Json.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaceMonster : MonoBehaviour
{
    public GameObject monsterPrefab;
    public GameObject monster;
    private GameManagerBehavior gameManager;
    private bool CanPlaceMonster()
    {
        int cost = monsterPrefab.GetComponent<MonsterData>().levels[0].cost;
        return monster == null && gameManager.Gold >= cost;
    }

    private bool CanUpgradeMonster()
    {
        if (monster != null)
        {
            MonsterData plantData = monster.GetComponent<MonsterData>();
            MonsterLevel nextLevel = plantData.GetNextLevel();
            if (nextLevel != null)
            {
                return gameManager.Gold >= nextLevel.cost;
            }
        }
        return false;
    }

    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManagerBehavior>();
    }
        void OnMouseUp()
        {
            if (CanPlaceMonster())
            {
                monster = (GameObject)
                    Instantiate(monsterPrefab, transform.position, Quaternion.identity);

            gameManager.Gold -= monster.GetComponent<MonsterData>().CurrentLevel.cost;

        }
        else if (CanUpgradeMonster())
        {
            monster.GetComponent<MonsterData>().IncreaseLevel();

            gameManager.Gold -= monster.GetComponent<MonsterData>().CurrentLevel.cost;

        }
    }

    // Update is called once per frame
    void Update()
    {

    }

}
