using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class ChoosePlant : MonoBehaviour
{
    public AudioSource placePlantSFX;
    public AudioSource firstUpgradeSFX;
    public AudioSource secondUpgradeSFX;
    public GameObject[] plants = new GameObject[4];
    public GameObject plantPrefab = null;
    public GameObject plant = null;
    private GameManagerBehavior gameManager;
    public GameObject CanvasObject = null;
    private GameObject plantChooser;
    private GameObject plantUpgrader1;
    private GameObject plantUpgrader2;
    public bool HasPlantTest = false;
    public bool plantUpgrade1 = false;
    public bool plantUpgrade2 = false;


    public void plantChoice(int x)
    {
        plantPrefab = plants[x];
    }
    public bool HasPlant()
    {
        if (plantPrefab == null)
        {
            return false;
        }
        else
        { HasPlantTest = true; return true;  }
    }
    public void placePlant()
    {
        placePlantSFX.Play();
        plant = (GameObject)
        Instantiate(plantPrefab, transform.position, Quaternion.identity);
    }

    public bool CanUpgrade1()
    {
        if (plantUpgrade1 == true)
        {
            return true;
        }
        else { return false; }
    }

    public bool CanUpgrade2()
    {
        if (plantUpgrade2 == true)
        {
            return true;
        }
        else { return false; }
    }

    public void upgrade1()
    {
        firstUpgradeSFX.Play();
        plant.GetComponent<PlantData>().IncreaseLevel();
    }

    public void upgrade2()
    {
        secondUpgradeSFX.Play();
        plant.GetComponent<PlantData>().IncreaseLevel();
    }

    private void OnMouseEnter()
    {
        if (HasPlant())
        {
            if (plantUpgrade1 == true && plantUpgrade2 == false)
            {
                plantUpgrader1.SetActive(true);
            }
            else if (plantUpgrade1 == true && plantUpgrade2 == true)
            {
                plantUpgrader2.SetActive(true);
            }
        }
        else if (!HasPlant())
        {
            plantChooser.SetActive(true);
        }
    }

    private void OnMouseExit()
    {
        if (HasPlant())
        {
            if (plantUpgrade1 == true && plantUpgrade2 == false)
            {
                plantUpgrader1.SetActive(false);
            }
            else if (plantUpgrade1 == true && plantUpgrade2 == true)
            {
                plantUpgrader2.SetActive(false);
            }
        }
        else if (!HasPlant())
        {
            plantChooser.SetActive(false);
        }
    }


    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManagerBehavior>();
        plantChooser = CanvasObject.GetComponent<CanvasObject>().Number1;
        plantUpgrader1 = CanvasObject.GetComponent<CanvasObject>().Number2;
        plantUpgrader2 = CanvasObject.GetComponent<CanvasObject>().Number3;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
