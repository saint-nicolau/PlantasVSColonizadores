using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Slider2 : MonoBehaviour
{
    [SerializeField] Slider SecondmusicSlider;
    public AudioSource SecondMusic;

    public void changeVolume()
    {
        SecondMusic.volume = SecondmusicSlider.value - 0.45f;
    }
}
