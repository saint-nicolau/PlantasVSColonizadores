using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Unity.VisualScripting;
using UnityEngine;

public class BulletBehavior : MonoBehaviour
{
    public float speed = 10;
    public float damage;
    public GameObject target;
    public Vector3 startPosition;
    public Vector3 targetPosition;
    //public variavel pro audio
    
    private float distance;
    private float startTime;
    public GameObject Ipe;
    public GameObject Mamona;
    private GameManagerBehavior gameManager;
    public List<bool> boosts = new List<bool>();
    public List<float> buffs = new List<float>();

    public float Buff(bool x, bool y, bool z)
    {
        float result = 1.0f;
        if (x)
        {
            result = buffs[2];
        }
        else if (y)
        {
            result = buffs[1];
        }
        else if (z)
        {
            result = buffs[0];
        }
        return result;

    }

    private void OnDestroy()
    {
        Debug.Log(damage * Buff(boosts[2], boosts[1], boosts[0]));
        // coloca o som do tiro aqui!
    }


    // Start is called before the first frame update
    void Start()
    {
        startTime = Time.time;
        distance = Vector3.Distance(startPosition, targetPosition);
        GameObject gm = GameObject.Find("GameManager");
        gameManager = gm.GetComponent<GameManagerBehavior>();
        for (int i = 0; i < buffs.Count; i++)
        {
            buffs[i] = Ipe.GetComponent<IpeShooting>().buffs[i];
        }
    }

    // Update is called once per frame
    void Update()
    {


        // 1 
        float timeInterval = Time.time - startTime;
        gameObject.transform.position = Vector3.Lerp(startPosition, targetPosition, timeInterval * speed / distance);

        // 2 
        if (gameObject.transform.position.Equals(targetPosition))
        {
            if (target != null)
            {
                // 3

                Transform healthBarTransform = target.transform.Find("Barra de Vida");
                HealthBar healthBar = healthBarTransform.gameObject.GetComponent<HealthBar>();
                healthBar.currentHealth -= Mathf.Max(damage * Buff(boosts[2], boosts[1], boosts[0]), 0);
                if (Mamona.GetComponent<PlantData>().isMamona == true && Mamona != null)
                {
                    target.GetComponent<MoveEnemy>().slow(Mamona, target);
                }

                // 4
                if (healthBar.currentHealth <= 0)
                {

                    Destroy(target);
              
                }
            }
            Destroy(gameObject);
        }

    }
}
