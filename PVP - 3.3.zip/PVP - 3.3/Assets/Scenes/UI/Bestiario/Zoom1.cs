using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Zoom1 : MonoBehaviour
{
    public GameObject CameraGeral;
    public GameObject CameraJabu;
    public GameObject PainelGeral;
    public GameObject PainelJabu;

    public void ZoomIN()
    {
        CameraGeral.SetActive(false);
        CameraJabu.SetActive(true);

        PainelGeral.SetActive(false);
        PainelJabu.SetActive(true);
    }

    public void ZoomOUT()
    {
        CameraGeral.SetActive(true);
        CameraJabu.SetActive(false);

        PainelGeral.SetActive(true);
        PainelJabu.SetActive(false);
    }
}
