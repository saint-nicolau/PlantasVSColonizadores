using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuPrincipalManager : MonoBehaviour

{
    [SerializeField] private string NomeDoJogo;

    [SerializeField] private GameObject PainelMenuInicial;

    [SerializeField] private GameObject PainelOp�oes;

    [SerializeField] private GameObject PainelSairJogo;


    public void Jogar()
    {
    
        SceneManager.LoadScene(NomeDoJogo);


    }


    public void AbrirOp��es()
    {
        PainelMenuInicial.SetActive(false);
        PainelOp�oes.SetActive(true);
    }


    public void FecharOp�oes()
    {
        PainelOp�oes.SetActive(false);
        PainelMenuInicial.SetActive(true);
    }


    public void SairJogo()
    {
        PainelMenuInicial.SetActive(false);
        PainelSairJogo.SetActive(true);

    }


    public void NegarSairJogo()
    {
        PainelSairJogo.SetActive(false);
        PainelMenuInicial.SetActive(true);
    }


    public void ConfirmarSairJogo()
    {
        Debug.Log("Sair do Jogo");
        Application.Quit();
    }
}


