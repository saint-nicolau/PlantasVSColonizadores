using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor.UI;

public class MenuManager : MonoBehaviour
{
    [SerializeField] private GameObject TelaMenuPrincipal;
    [SerializeField] private GameObject TelaOpcoes;
    [SerializeField] private GameObject TelaSair;
    [SerializeField] private GameObject TelaExtras;
    [SerializeField] private GameObject TelaCreditos;
    [SerializeField] private GameObject TelaFases;
    [SerializeField] private GameObject TelaTutorialUM;
    [SerializeField] private GameObject TelaTutorialDOIS;
    [SerializeField] private GameObject Davide;

    // // // / // // // // // // // // // // // // // // // // 
    public void AbrirFases()
    {
        TelaMenuPrincipal.SetActive(false);
        TelaFases.SetActive(true);
    }
    public void FecharFase()
    {
        TelaFases.SetActive(false);
        TelaMenuPrincipal.SetActive(true);
    }
    public void AbrirOpcoes()
    {
        TelaMenuPrincipal.SetActive(false);
        TelaOpcoes.SetActive(true);
    }
    public void FecharOpcoes()
    {
        TelaOpcoes.SetActive(false);
        TelaMenuPrincipal.SetActive(true);
    }
    public void AbrirSair()
    {
        TelaMenuPrincipal.SetActive(false);
        TelaSair.SetActive(true);
    }
    public void FecharSair()
    {
        TelaSair.SetActive(false);
        TelaMenuPrincipal.SetActive(true);
    }
    public void AbrirExtras()
    {
        TelaOpcoes.SetActive(false);
        TelaExtras.SetActive(true);
    }
    public void FecharExtras()
    {
        TelaExtras.SetActive(false);
        TelaOpcoes.SetActive(true);
    }
    public void AbrirCreditos()
    {
        TelaExtras.SetActive(false);
        TelaCreditos.SetActive(true);
    }
    public void FecharCreditos()
    {
        TelaCreditos.SetActive(false);
        TelaExtras.SetActive(true);
        Davide.SetActive(false);
    }
    public void AbrirTutorialUM()
    {
        TelaFases.SetActive(false);
        TelaTutorialUM.SetActive(true);
    }
    public void AbrirTutoria()
    {
        TelaFases.SetActive(false);
        TelaTutorialDOIS.SetActive(true);
    }









}

 
