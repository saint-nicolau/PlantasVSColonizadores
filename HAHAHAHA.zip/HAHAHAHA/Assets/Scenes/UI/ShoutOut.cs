using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ShoutOut : MonoBehaviour
{
    public GameObject ShoutOutDavide;

    public void openText()
    {
        ShoutOutDavide.SetActive(true);
    }
}
