using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using JetBrains.Annotations;
using System.Diagnostics.CodeAnalysis;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Unity.VisualScripting;


public class StartScene : MonoBehaviour   
{  
    public void StartGame()
    {                  
        SceneManager.LoadScene("GAMESCENE");
        Time.timeScale = 1;
    } 
}
