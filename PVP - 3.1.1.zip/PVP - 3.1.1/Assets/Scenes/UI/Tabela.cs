using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Tabela : MonoBehaviour
{
    public GameObject ImagemTabela;
    public GameObject SetaAbrirTabela;
    public GameObject SetaFecharTabela;

    public void AbrirTabela()
    {
        SetaAbrirTabela.SetActive(false);
        SetaFecharTabela.SetActive(true);
        ImagemTabela.SetActive(true);
    }

    public void FecharTabela()
    {
        ImagemTabela.SetActive(false);
        SetaFecharTabela.SetActive(false);
        SetaAbrirTabela.SetActive(true);
    }


}
