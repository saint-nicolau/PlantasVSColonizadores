using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Acelerar : MonoBehaviour
{
    public GameObject ClockONE;
    public GameObject ClockTWO;
    public GameObject ClockTHREE;
    public void SpeedONE()
    {
        ClockTWO.SetActive(true);
        ClockONE.SetActive(false);
        ClockTHREE.SetActive(false);
        Time.timeScale = 1.5f;
    }

    public void SpeedTWO()
    {
        ClockTHREE.SetActive(true);
        ClockONE.SetActive(false);
        ClockTWO.SetActive(false);
        Time.timeScale = 2f;
    }

    public void SpeedTHREE()
    {
        ClockONE.SetActive(true);
        ClockTWO.SetActive(false);
        ClockTHREE.SetActive(false);
        Time.timeScale = 1;
    }

}
