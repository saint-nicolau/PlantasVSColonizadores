using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Trocar : MonoBehaviour
{
    public GameObject CameraPlantas;
    public GameObject CameraPortugueses;
    public GameObject PainelPlantas;
    public GameObject PainelPortugueses;

    public void TrocarPortugues()
    {
        CameraPortugueses.SetActive(true);
        PainelPortugueses.SetActive(true);
        CameraPlantas.SetActive(false);
        PainelPlantas.SetActive(false);
    }

    public void TrocarPlantas()
    {
        CameraPlantas.SetActive (true);
        PainelPlantas.SetActive(true);
        CameraPortugueses.SetActive(false);
        PainelPortugueses.SetActive (false);
    }
}
