using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zoom2 : MonoBehaviour
{
    public GameObject CameraGeral;
    public GameObject CameraMamona;
    public GameObject PainelGeral;
    public GameObject PainelMamona;

    public void ZoomIN()
    {
        CameraGeral.SetActive(false);
        CameraMamona.SetActive(true);

        PainelGeral.SetActive(false);
        PainelMamona.SetActive(true);
    }

    public void ZoomOUT()
    {
        CameraGeral.SetActive(true);
        CameraMamona.SetActive(false);

        PainelGeral.SetActive(true);
        PainelMamona.SetActive(false);
    }



}