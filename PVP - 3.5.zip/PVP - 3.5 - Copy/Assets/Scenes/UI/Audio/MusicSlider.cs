using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MusicSlider : MonoBehaviour
{
    [SerializeField] Slider musicSlider;
    public AudioSource Music;

    private void Awake()
    {
        Music.Play();
    }
    public void changeMusicVolume()
    {
        Music.volume = musicSlider.value - 0.2f;
    }
}
