using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManagerBehavior : MonoBehaviour
{
    public GameObject winPanel;
    public GameObject losePanel;
    public AudioSource VictorySFX;
    public AudioSource DefeatSFX;

    public int[] enemyGold;
    public Text goldLabel;
    private int gold;
    public int startGold = 120;
    public int Gold
    
        
    {
        get
        {
            return gold;
        }
        set
        {
            gold = value;
            if (goldLabel!=null) goldLabel.text = "Ouro: " + gold;
        }
    }

    public Text waveLabel;
    //public GameObject[] nextWaveLabels;

    public bool gameOver = false;
    bool victoryOver = false;
    private int wave;
    public int Wave
    {
        get
        {
            return wave;
        }
        set
        {
            wave = value;

            waveLabel.text = "Horda: " + (wave + 1);
        }
    }

    public Text healthLabel;
    public GameObject[] healthIndicator;

    private int health;
    public int Health
    {
        get
        {
            return health;
        }
        set
        {
            // 1
            if (value < health)
            {
                //Camera.main.GetComponent<CameraShake>().Shake();
            }
            // 2
            health = value;
            healthLabel.text = "Vida: " + health;
            // 3
            if (health <= 0 && !gameOver)
            {
                gameOver = true;
                DefeatSFX.Play();
            }
            // 4 
            for (int i = 0; i < healthIndicator.Length; i++)
            {
                if (i < Health)
                {
                    healthIndicator[i].SetActive(true);
                }
                else
                {
                    healthIndicator[i].SetActive(false);
                }
            }
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        Gold = startGold;
        Wave = 0;
        Health = 5;
    }

    // Update is called once per frame
    void Update()
    {
        if (Health == 0)
        {
            losePanel.SetActive(true);
            Time.timeScale = 0f;
        }

        if (gold >= 100000)
        {
            if (victoryOver == false)
            {
                victoryOver = true;
                VictorySFX.Play();
                winPanel.SetActive(true);
            }
        }
    }
}
