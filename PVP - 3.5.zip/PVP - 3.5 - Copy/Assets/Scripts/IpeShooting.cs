using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IpeShooting : MonoBehaviour
{
    public int ipeLevel;
    public List<bool> boosts = new List<bool>();
    public List<GameObject> enemiesInRange;
    public List<float> buffs = new List<float>();

    void OnEnemyDestroy(GameObject enemy)
    {
        enemiesInRange.Remove(enemy);

    }

    void OnTriggerEnter(Collider other)
    {
        // 2
        if (other.gameObject.tag.Equals("Bullet"))
        {
            enemiesInRange.Add(other.gameObject);
            EnemyDestructionDelegate del =
                other.gameObject.GetComponent<EnemyDestructionDelegate>();
            del.enemyDelegate += OnEnemyDestroy;
        }
    }
    // 3
    void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag.Equals("Plant"))
        {
            enemiesInRange.Remove(other.gameObject);
            EnemyDestructionDelegate del =
                other.gameObject.GetComponent<EnemyDestructionDelegate>();
            del.enemyDelegate -= OnEnemyDestroy;
        }
    }







    // Start is called before the first frame update
    void Start()
    {
        enemiesInRange = new List<GameObject>();
    }

    // Update is called once per frame
    void Update()
    {
        ipeLevel = this.GetComponent<PlantData>().currentLevel.plantLevel;
        for (int i = 0; i <= enemiesInRange.Count; i++)
        {
            if (enemiesInRange[i] == null)
            {
                enemiesInRange.Remove(enemiesInRange[i]);
            }
            else
            {
                enemiesInRange[i].GetComponent<BulletBehavior>().boosts[ipeLevel] = this.boosts[ipeLevel];
            }
        }
        for (int i = 0; i <= boosts.Count; i++)
        {
            if (i == ipeLevel)
            {
                boosts[i] = true;
            }
            else
            {
                boosts[i] = false;
            }
        }
        for (int i = 0; i <= enemiesInRange.Count; i++)
        {

        }



        //for (int i = 0; i < enemiesInRange.Count; i++)
        //{
        //    if (ipeLevel == i)
        //    {
        //        enemiesInRange[i].GetComponent<BulletBehavior>().ipeBoost[i] = true;
        //    }

        //}
    }
}
