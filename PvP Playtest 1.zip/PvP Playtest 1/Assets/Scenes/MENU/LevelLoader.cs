using JetBrains.Annotations;
using System.Collections;
using System.Diagnostics.CodeAnalysis;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections.Generic;
using Unity.VisualScripting;

public class LevelLoader : MonoBehaviour

{
    [SerializeField] private GameObject PainelStart;
    
    public GameObject LoadingScreen;
    public Slider slider;

    ///------------------------------------------------\\\
   

    
    public void LoadingScene (int sceneIndex)
    {
        SceneManager.LoadScene(sceneIndex);
        PainelStart.SetActive(true);
    }
  
    void Update()
    {      
        {
            if (PainelStart != null )
            {
                FreezeStart();
            }
            else
            {
                StartScene();       
                
            }
                                                  
        }
    }
    public void StartScene()
    {
        PainelStart = null;
        Time.timeScale = 1;     
    }
    private void FreezeStart()
    {
        PainelStart.SetActive(true);
        Time.timeScale = 0f;
    }
    

    //--------------------------------------------//


    public void LoadLevel(int sceneIndex)
   
    {
        StartCoroutine(LoadAsynchrounously(sceneIndex));
    }
    IEnumerator LoadAsynchrounously(int sceneIndex)
    {
        AsyncOperation operation = SceneManager.LoadSceneAsync(sceneIndex);


        while (!operation.isDone) 
        {
            float progress = Mathf.Clamp01(operation.progress / .9f);
            slider.value = progress;

            yield return null;
        }

    }

}
