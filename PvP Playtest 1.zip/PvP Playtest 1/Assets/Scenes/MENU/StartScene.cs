using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using JetBrains.Annotations;
using System.Diagnostics.CodeAnalysis;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Unity.VisualScripting;


public class StartScene : MonoBehaviour
{
    [SerializeField]
    private GameObject PainelStart;

    public void LoadingScene(int sceneIndex)
    {
        SceneManager.LoadScene(sceneIndex);
        PainelStart.SetActive(true);
    }

    void Update()
    {
        {
            if (PainelStart != null)
            {
                FreezeStart();
            }
            else
            {
                RunScene();

            }

        }
    }

    public void RunScene()
    {
        PainelStart = null;
        Time.timeScale = 1;
    }
    private void FreezeStart()
    {
        PainelStart.SetActive(true);
        Time.timeScale = 0f;
    }

}

