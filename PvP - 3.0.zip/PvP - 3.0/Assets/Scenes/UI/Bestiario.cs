using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class Bestiario : MonoBehaviour
{
    public void EntrarBestiario()
    {
        SceneManager.LoadScene("BESTIARIO");
        //Time.timeScale = 1;
    }
}