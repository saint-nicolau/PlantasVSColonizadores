using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zoom4 : MonoBehaviour
{
    public GameObject CameraGeral;
    public GameObject CameraIpe;
    public GameObject PainelGeral;
    public GameObject PainelIpe;

    public void ZoomIN()
    {
        CameraGeral.SetActive(false);
        CameraIpe.SetActive(true);

        PainelGeral.SetActive(false);
        PainelIpe.SetActive(true);
    }

    public void ZoomOUT()
    {
        CameraGeral.SetActive(true);
        CameraIpe.SetActive(false);

        PainelGeral.SetActive(true);
        PainelIpe.SetActive(false);
    }
}
