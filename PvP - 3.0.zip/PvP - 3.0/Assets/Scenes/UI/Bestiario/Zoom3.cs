using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zoom3 : MonoBehaviour
{
    public GameObject CameraGeral;
    public GameObject CameraJaca;
    public GameObject PainelGeral;
    public GameObject PainelJaca;

    public void ZoomIN()
    {
        CameraGeral.SetActive(false);
        CameraJaca.SetActive(true);

        PainelGeral.SetActive(false);
        PainelJaca.SetActive(true);
    }

    public void ZoomOUT()
    {
        CameraGeral.SetActive(true);
        CameraJaca.SetActive(false);

        PainelGeral.SetActive(true);
        PainelJaca.SetActive(false);
    }
}
