using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class PlantChooser : MonoBehaviour
{
    public int x;
    public GameObject ChosenPlant;
    public GameObject ChoosePlant;
    public GameObject PlantChooserDestroy;
    public GameObject plantPrefab;
    public GameObject plant;
    public GameObject myPlant;
    public GameManagerBehavior gameManager;
    public int gold;
    public PlantChooser nextLevelChooser;

    public void PlantChoice()
    {
        if (!ChoosePlant.GetComponent<ChoosePlant>().HasPlant())
        {
            // if gameManager.Gold is bigger than the cost
            if (myPlant.GetComponent<PlantData>().levels[0].cost <= gold)
            {
            ChoosePlant.GetComponent<ChoosePlant>().plantChoice(x);
            ChoosePlant.GetComponent<ChoosePlant>().placePlant();
            ChoosePlant.GetComponent<ChoosePlant>().plantUpgrade1 = true;
            gameManager.Gold -= myPlant.GetComponent<PlantData>().levels[0].cost;
            nextLevelChooser.x = x;
            Destroy(PlantChooserDestroy);
            }
        }
    }

    public void PlantUpgrade1()
    {
        if(ChoosePlant.GetComponent<ChoosePlant>().CanUpgrade1())
        {
            if (myPlant.GetComponent<PlantData>().levels[1].cost <= gold)
            {
                ChoosePlant.GetComponent<ChoosePlant>().upgrade1();
                ChoosePlant.GetComponent<ChoosePlant>().plantUpgrade2 = true;
                gameManager.Gold -= myPlant.GetComponent<PlantData>().levels[1].cost;
                nextLevelChooser.x = x;
                Destroy(PlantChooserDestroy);
            }

        }
    }

    public void PlantUpgrade2()
    {
        if(ChoosePlant.GetComponent<ChoosePlant>().CanUpgrade2())
        {
            if (myPlant.GetComponent<PlantData>().levels[2].cost <= gold)
            {
                ChoosePlant.GetComponent<ChoosePlant>().upgrade2();
                gameManager.Gold -= myPlant.GetComponent<PlantData>().levels[2].cost;
                Destroy(PlantChooserDestroy);
            }

        }
    }


    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManagerBehavior>();
        gold = gameManager.Gold;
        ChoosePlant = ChosenPlant.GetComponent<CanvasObject>().ChoosePlant;
        plantPrefab = ChosenPlant.GetComponent<CanvasObject>().ChoosePlant.GetComponent<ChoosePlant>().plantPrefab;
        plant = ChosenPlant.GetComponent<CanvasObject>().ChoosePlant.GetComponent<ChoosePlant>().plant;
            myPlant = ChoosePlant.GetComponent<ChoosePlant>().plants[x];
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
